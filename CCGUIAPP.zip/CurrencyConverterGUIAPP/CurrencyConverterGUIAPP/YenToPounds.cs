﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverterGUIAPP
{
    class YenToPounds
    {
        //
        private double TheValue;

        //constructor
        public YenToPounds(double t)
        {
            this.TheValue = t;
        }//end con

        //setter
        public void SetYenToPounds(double t)
        {
            this.TheValue = t;
        }//end set

        //getter
        public double TheRatio()
        {
            double result = this.TheValue * 0.0068;
            TheValue = result;
            return TheValue;
        }//end get
    }
}
