﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CurrencyConverterGUIAPP
{
    public partial class CurrencyConverter : Form
    {
        public CurrencyConverter()
        {
            InitializeComponent();
        }

        private void CurrencyConverter_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int throwAway = 0;
            /*
             Pounds to Euros
            Euros to Pounds
            Pounds to Dollars
            Dollars to Pounds
            Pounds to Yen
            Yen to Pounds
            Pounds to Rupee
            Rupee to Pounds 
             */

            if (textBox1.TextLength > 0) {
                string tempVar = comboBox1.GetItemText(comboBox1.SelectedItem);
                switch (tempVar)
                {
                    case "Pounds to Euros":
                        PoundsToEuros poundsToEuros = new PoundsToEuros(Convert.ToDouble(textBox1.Text));
                        double resultOfCon = poundsToEuros.TheRatio();
                        textBox2.Text = Convert.ToString(resultOfCon);
                        break;
                    case "Euros to Pounds":
                        EurosToPounds eurosToPounds = new EurosToPounds(Convert.ToDouble(textBox1.Text));
                        double resultOfCon2 = eurosToPounds.TheRatio();
                        textBox2.Text = Convert.ToString(resultOfCon2);
                        break;
                    case "Pounds to Dollars":
                        PoundsToDollars poundsToDollars = new PoundsToDollars(Convert.ToDouble(textBox1.Text));
                        double resultOfCon3 = poundsToDollars.TheRatio();
                        textBox2.Text = Convert.ToString(resultOfCon3);
                        break;
                    case "Dollars to Pounds":
                        DollarsToPounds dollarsToPounds = new DollarsToPounds(Convert.ToDouble(textBox1.Text));
                        double resultOfCon4 = dollarsToPounds.TheRatio();
                        textBox2.Text = Convert.ToString(resultOfCon4);
                        break;
                    case "Pounds to Yen":
                        PoundsToYen poundsToYen = new PoundsToYen(Convert.ToDouble(textBox1.Text));
                        double resultOfCon5 = poundsToYen.TheRatio();
                        textBox2.Text = Convert.ToString(resultOfCon5);
                        break;
                    case "Yen to Pounds":
                        YenToPounds yenToPounds = new YenToPounds(Convert.ToDouble(textBox1.Text));
                        double resultOfCon6 = yenToPounds.TheRatio();
                        textBox2.Text = Convert.ToString(resultOfCon6);
                        break;
                    case "Pounds to Rupee":
                        PoundsToRupee poundsToRupee = new PoundsToRupee(Convert.ToDouble(textBox1.Text));
                        double resultOfCon7 = poundsToRupee.TheRatio();
                        textBox2.Text = Convert.ToString(resultOfCon7);
                        break;
                    case "Rupee to Pounds":
                        RupeeToPounds rupeeToPounds = new RupeeToPounds(Convert.ToDouble(textBox1.Text));
                        double resultOfCon8 = rupeeToPounds.TheRatio();
                        textBox2.Text = Convert.ToString(resultOfCon8);
                        break;
                    default:
                        MessageBox.Show("Could not determine conversion, please try again.");
                        break;
                }//end switch
            }
            else
            {
                MessageBox.Show("Please enter a number.");
            }
        }//end

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
          e.Handled = !char.IsDigit(e.KeyChar);
        }
    }//end class
}//end namespace
