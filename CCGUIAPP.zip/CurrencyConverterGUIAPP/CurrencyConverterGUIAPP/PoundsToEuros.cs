﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverterGUIAPP
{
    class PoundsToEuros
    {
        //
        private double TheValue;

        //constructor
        public PoundsToEuros(double t)
        {
            this.TheValue = t;
        }//end con

        //setter
        public void SetPoundsToEuros(double t)
        {
            this.TheValue = t; 
        }//end set

        //getter
        public double TheRatio()
        {
            double result = this.TheValue * 1.17;
            TheValue = result;
            return TheValue;
        }//end get

    }//end class
}//end name
