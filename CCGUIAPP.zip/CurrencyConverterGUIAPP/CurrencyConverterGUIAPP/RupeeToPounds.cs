﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverterGUIAPP
{
    class RupeeToPounds
    {
        //
        private double TheValue;

        //constructor
        public RupeeToPounds(double t)
        {
            this.TheValue = t;
        }//end con

        //setter
        public void SetRupeeToPounds(double t)
        {
            this.TheValue = t;
        }//end set

        //getter
        public double TheRatio()
        {
            double result = this.TheValue * 0.01;
            TheValue = result;
            return TheValue;
        }//end get
    }
}
