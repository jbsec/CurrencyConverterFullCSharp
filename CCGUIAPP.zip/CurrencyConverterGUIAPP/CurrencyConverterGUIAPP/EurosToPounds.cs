﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverterGUIAPP
{
    class EurosToPounds
    {
        //
        private double TheValue;

        //constructor
        public EurosToPounds(double t)
        {
            this.TheValue = t;
        }//end con

        //setter
        public void SetEurosToPounds(double t)
        {
            this.TheValue = t;
        }//end set

        //getter
        public double TheRatio()
        {
            double result = this.TheValue * 0.86;
            TheValue = result;
            return TheValue;
        }//end get

    }//end class
}

