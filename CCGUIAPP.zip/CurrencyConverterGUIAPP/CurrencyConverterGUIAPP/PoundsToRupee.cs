﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverterGUIAPP
{
    class PoundsToRupee
    {
        //
        private double TheValue;

        //constructor
        public PoundsToRupee(double t)
        {
            this.TheValue = t;
        }//end con

        //setter
        public void SetPoundsToRupee(double t)
        {
            this.TheValue = t;
        }//end set

        //getter
        public double TheRatio()
        {
            double result = this.TheValue * 91.93;
            TheValue = result;
            return TheValue;
        }//end get
    }
}
